import axios from "axios";

const API_BASE_URL =
  import.meta.env.VITE_API_URL || "http://localhost:8080/api";

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: { "Content-Type": "application/json" },
});

// AUTO-ADD TOKEN
api.interceptors.request.use((config) => {
  const token = sessionStorage.getItem("authToken");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// SIMPLE REFRESH TOKEN LOGIC
let isRefreshing = false;

const refreshAccessToken = async () => {
  const refreshToken = sessionStorage.getItem("refreshToken");
  console.log("refreshAccessToken called, refreshToken =", !!refreshToken);
  if (!refreshToken) return false;

  try {
    const response = await axios.post(
      `${API_BASE_URL}/auth/refresh-token`,
      {},
      {
        headers: { Authorization: `Bearer ${refreshToken}` },
      }
    );
    console.log("refresh status", response.status, response.data);

    // backend returns { token, refreshToken? }
    const { token, refreshToken: newRefresh } = response.data;
    if (!token) return false;

    sessionStorage.setItem("authToken", token);
    if (newRefresh) {
      sessionStorage.setItem("refreshToken", newRefresh);
    }
    return true;
  } catch (e) {
    console.log("refresh failed", e.response?.status, e.response?.data);
    return false;
  }
};

// AUTO-LOGOUT ON 401 WITH REFRESH
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (!error.response) {
      return Promise.reject(error);
    }

    const status = error.response.status;
    const isRefreshCall = originalRequest?.url?.includes("/auth/refresh-token");

    if (
      status === 401 &&
      !isRefreshing &&
      !originalRequest._retry &&
      !isRefreshCall
    ) {
      originalRequest._retry = true;
      isRefreshing = true;

      const refreshed = await refreshAccessToken();

      isRefreshing = false;

      if (refreshed) {
        const newToken = sessionStorage.getItem("authToken");
        if (newToken) {
          originalRequest.headers = originalRequest.headers || {};
          originalRequest.headers.Authorization = `Bearer ${newToken}`;
        }
        return api(originalRequest);
      }
    }

    if (status === 401) {
      sessionStorage.clear();
      window.location.href = "/login?sessionExpired=true";
    }

    return Promise.reject(error);
  }
);

export const apiService = {
  // AUTH
  login: (username, password) =>
    api.post("/auth/login", { username, password }),

  // PUBLIC ENDPOINT (no interceptor)
  changePasswordFirstLogin: async (oldPassword, newPassword, username) => {
    const publicApi = axios.create({
      baseURL: API_BASE_URL,
      headers: { "Content-Type": "application/json" },
    });
    return publicApi.post("/users/change-password-first-login", {
      username,
      oldPassword,
      newPassword,
    });
  },

  refreshAccessToken,

  // USER INFO
  getCurrentUser: () => api.get("/auth/me"),

  // USER PROFILE (IMPORTANT: uses `api` with interceptors)
  getUserProfile: () => api.get("/users/profile"),

  // DASHBOARD (protected)
  getAssignedTasks: () => api.get("/tasks/assigned"),
  getAttendance: () => api.get("/attendance/current"),
  getSchedule: () => api.get("/schedule/today"),
  getNotices: () => api.get("/notices/active"),
};

export default api;
