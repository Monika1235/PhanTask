import React from 'react'

const Feedback = () => {
  return (
    <div>Feedback</div>
  )
}

export default Feedback