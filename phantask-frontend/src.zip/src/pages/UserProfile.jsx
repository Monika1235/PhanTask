import React, { useEffect, useState } from "react";
import { apiService } from "../services/api";
import { toast } from "react-hot-toast";
import LoadingSkeleton from "../components/LoadingSkeleton";
import mascot from "../assets/Mascot-Phantask.png";

const UserProfile = ({ onEdit }) => {
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        apiService
            .getUserProfile()
            .then((res) => setProfile(res.data))
            .catch((err) => {
                toast.error(err.response?.data?.message || "Failed to load profile");
            })
            .finally(() => setLoading(false));

    }, []);

    if (loading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50 p-3 md:p-4">
                <div className="max-w-7xl mx-auto flex items-center justify-center">
                    <LoadingSkeleton
                        titleHeight="h-6"
                        rows={6}
                        rowHeight="h-5"
                        hasButton={true}
                        className="w-[90%] h-[90%] max-w-4xl"
                    />
                </div>
            </div>
        );
    }

    if (!profile) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50 p-3 md:p-4">
                <div className="max-w-7xl mx-auto flex items-center justify-center text-sm text-[#522320]">
                    Unable to load profile.
                </div>
            </div>
        );
    }

    console.log(profile);
    return (
        <div className="h-screen bg-gradient-to-br from-gray-50 to-orange-50 p-3 md:p-4">
            <div className="max-w-[90%] h-[90%] mx-auto flex items-center justify-center">
                {/* Main profile card – similar feel to Login container */}
                <section className="w-full min-h-full rounded-2xl bg-white/60 backdrop-blur-sm border border-[#E7B9AE] shadow-md shadow-[#522320]/20 px-5 sm:px-6 md:px-8 py-5 flex flex-col gap-4">

                    {/* Header */}
                    <header className="h-24 flex items-center justify-between">
                        <div className="flex flex-col w-full">
                            <h2 className="text-2xl md:text-3xl text-center font-bold text-amber-950">
                                My Profile
                            </h2>
                            <p className="text-sm font-normal text-center text-amber-950">
                                Manage your PhanTask account details.
                            </p>
                        </div>
                        <div className="h-16 w-16 rounded-full border-2 border-orange-400 flex items-center justify-center">
                            <img
                                className="h-full w-full rounded-full object-cover"
                                src={profile.photoUrl || mascot}
                                alt="profile"
                            />
                        </div>

                    </header>

                    {/* Content – flex, responsive like your login layout */}
                    <div className="mt-2 text-sm text-[#522320]">
                        {/* Left column */}
                        <div className="">
                            <div>
                                <span className="font-semibold text-[#3b1d18]">
                                    Username:
                                </span>{" "}
                                <span className="text-[#5b3627] break-all">
                                    {profile.username}
                                </span>
                            </div>
                            <div>
                                <span className="font-semibold text-[#3b1d18]">Email:</span>{" "}
                                <span className="text-[#5b3627] break-all">
                                    {profile.email}
                                </span>
                            </div>
                            <div>
                                <span className="font-semibold text-[#3b1d18]">
                                    Primary role:
                                </span>{" "}
                                <span className="inline-flex items-center rounded-full bg-[#FCE0D6] px-2 py-0.5 text-[11px] font-medium text-[#8c432b]">
                                    {profile.role}
                                </span>
                            </div>
                            <div>
                                <span className="font-semibold text-[#3b1d18]">
                                    All roles:
                                </span>{" "}
                                <span className="text-[#5b3627]">
                                    {Array.from(profile.roles || []).join(", ") || "N/A"}
                                </span>
                            </div>
                        </div>

                        {/* Right column */}
                        <div className="">
                            <div>
                                <span className="font-semibold text-[#3b1d18]">
                                    Full name:
                                </span>{" "}
                                <span className="text-[#5b3627]">
                                    {profile.fullName || "N/A"}
                                </span>
                            </div>
                            <div>
                                <span className="font-semibold text-[#3b1d18]">
                                    Department:
                                </span>{" "}
                                <span className="text-[#5b3627]">
                                    {profile.department || "N/A"}
                                </span>
                            </div>
                            <div>
                                <span className="font-semibold text-[#3b1d18]">Phone:</span>{" "}
                                <span className="text-[#5b3627]">
                                    {profile.phone || "N/A"}
                                </span>
                            </div>
                            <div>
                                <span className="font-semibold text-[#3b1d18]">
                                    Year of study:
                                </span>{" "}
                                <span className="text-[#5b3627]">
                                    {profile.yearOfStudy || "N/A"}
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Footer – Edit button */}
                    <div className="h-12 mt-3 flex justify-end">
                        <button
                            type="submit"
                            className="hover:scale-95 transition-transform-colors duration-300 flex-1 bg-red-700 hover:bg-red-800 text-white font-semibold py-2 rounded-lg shadow"
                        >
                            <i className="fa-solid fa-pen" />
                            <span>Edit details</span>
                        </button>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default UserProfile;
