import React from 'react'

const SocialHub = () => {
  return (
    <div>SocialHub</div>
  )
}

export default SocialHub